import React from 'react';
import { Avenger } from '../types/avenger';
import { Shield } from 'lucide-react';

interface AvengerCardProps {
  avenger: Avenger;
}

const AvengerCard: React.FC<AvengerCardProps> = ({ avenger }) => {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform duration-300 hover:shadow-lg hover:-translate-y-1">
      <div className="bg-[#E23636] text-white px-4 py-3 flex items-center">
        <Shield className="mr-2 h-5 w-5" />
        <h3 className="text-xl font-bold">{avenger.alias}</h3>
      </div>
      
      <div className="p-5">
        <div className="mb-4">
          <p className="text-sm text-gray-500">Real Name</p>
          <p className="font-semibold">{avenger.name}</p>
        </div>
        
        <div className="mb-4">
          <p className="text-sm text-gray-500">Portrayed By</p>
          <p className="font-semibold">{avenger.actor}</p>
        </div>
        
        <div className="mb-4">
          <p className="text-sm text-gray-500">Description</p>
          <p className="text-gray-700">{avenger.description}</p>
        </div>
        
        <div>
          <p className="text-sm text-gray-500 mb-1">Abilities</p>
          <div className="flex flex-wrap gap-2">
            {avenger.abilities.map((ability, index) => (
              <span 
                key={index} 
                className="bg-[#F1C40F] text-[#202020] text-xs px-2 py-1 rounded-full"
              >
                {ability}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AvengerCard;