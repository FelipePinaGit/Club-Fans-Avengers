export interface Avenger {
  id?: number;
  name: string;
  alias: string;
  actor: string;
  description: string;
  abilities: string[];
}

export interface AvengerFormData {
  name: string;
  alias: string;
  actor: string;
  description: string;
  abilities: string;
}

export interface AvengerFormErrors {
  name?: string;
  alias?: string;
  actor?: string;
  description?: string;
  abilities?: string;
}