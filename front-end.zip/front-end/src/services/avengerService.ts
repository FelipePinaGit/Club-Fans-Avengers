import axios from 'axios';
import { Avenger } from '../types/avenger';

const API_URL = 'http://localhost:3000/api/avengers';

export const getAvengers = async (): Promise<Avenger[]> => {
  try {
    const response = await axios.get<Avenger[]>(API_URL);
    return response.data;
  } catch (error) {
    console.error('Error fetching avengers:', error);
    throw error;
  }
};

export const createAvenger = async (avenger: Avenger): Promise<Avenger> => {
  try {
    const response = await axios.post<Avenger>(API_URL, avenger);
    return response.data;
  } catch (error) {
    console.error('Error creating avenger:', error);
    throw error;
  }
};